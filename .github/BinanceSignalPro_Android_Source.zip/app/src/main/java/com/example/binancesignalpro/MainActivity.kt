package com.example.binancesignalpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import kotlin.math.abs

data class Signal(
    val symbol: String,
    val market: String,
    val direction: String,
    val price: Double,
    val rsi15: Double,
    val rsi1h: Double,
    val macd15: String,
    val macd1h: String,
    val note: String
)

class BinanceApi {
    private val client = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private fun get(url: String): String {
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Binance HTTP ${response.code}")
            return response.body?.string() ?: error("Empty response")
        }
    }

    fun symbols(futures: Boolean): List<String> {
        val base = if (futures) "https://fapi.binance.com/fapi/v1/exchangeInfo"
                   else "https://api.binance.com/api/v3/exchangeInfo"
        val arr = org.json.JSONObject(get(base)).getJSONArray("symbols")
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("status") == "TRADING" &&
                s.optString("quoteAsset") == "USDT" &&
                s.optString("isSpotTradingAllowed", "true") != "false") {
                out.add(s.optString("symbol"))
            }
        }
        return out.distinct().sorted()
    }

    fun candles(symbol: String, interval: String, futures: Boolean): List<DoubleArray> {
        val root = if (futures) "https://fapi.binance.com/fapi/v1/klines"
                   else "https://api.binance.com/api/v3/klines"
        val url = "$root?symbol=$symbol&interval=$interval&limit=120"
        val a = JSONArray(get(url))
        val rows = mutableListOf<DoubleArray>()
        for (i in 0 until a.length()) {
            val k = a.getJSONArray(i)
            rows.add(doubleArrayOf(k.getString(4).toDouble(), k.getString(6).toDouble()))
        }
        // Exclude the currently forming candle.
        return if (rows.size > 2) rows.dropLast(1) else rows
    }

    fun lastPrice(symbol: String, futures: Boolean): Double {
        val root = if (futures) "https://fapi.binance.com/fapi/v1/ticker/price"
                   else "https://api.binance.com/api/v3/ticker/price"
        return org.json.JSONObject(get("$root?symbol=$symbol")).getString("price").toDouble()
    }
}

private fun ema(values: List<Double>, period: Int): List<Double> {
    if (values.isEmpty()) return emptyList()
    val alpha = 2.0 / (period + 1.0)
    val result = MutableList(values.size) { 0.0 }
    result[0] = values[0]
    for (i in 1 until values.size) result[i] = alpha * values[i] + (1 - alpha) * result[i - 1]
    return result
}

private fun rsi(values: List<Double>, period: Int = 14): Double {
    if (values.size <= period) return 50.0
    var gains = 0.0
    var losses = 0.0
    for (i in 1..period) {
        val d = values[i] - values[i - 1]
        if (d > 0) gains += d else losses -= d
    }
    var avgGain = gains / period
    var avgLoss = losses / period
    for (i in period + 1 until values.size) {
        val d = values[i] - values[i - 1]
        avgGain = (avgGain * (period - 1) + maxOf(d, 0.0)) / period
        avgLoss = (avgLoss * (period - 1) + maxOf(-d, 0.0)) / period
    }
    if (avgLoss == 0.0) return 100.0
    val rs = avgGain / avgLoss
    return 100.0 - (100.0 / (1.0 + rs))
}

private fun macdState(values: List<Double>): Pair<Boolean, Boolean> {
    if (values.size < 35) return false to false
    val fast = ema(values, 12)
    val slow = ema(values, 26)
    val line = values.indices.map { fast[it] - slow[it] }
    val signal = ema(line, 9)
    val n = line.lastIndex
    val bullish = line[n] > signal[n] && line[n - 1] <= signal[n - 1]
    val bearish = line[n] < signal[n] && line[n - 1] >= signal[n - 1]
    return bullish to bearish
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SignalScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignalScreen() {
    val scope = rememberCoroutineScope()
    val api = remember { BinanceApi() }
    var futures by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready — press Scan to start") }
    var results by remember { mutableStateOf(listOf<Signal>()) }
    var scanned by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("Binance Signal Pro") })
        }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                Text("Spot + Futures market scanner", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !futures, onClick = { futures = false }, label = { Text("Spot") })
                    FilterChip(selected = futures, onClick = { futures = true }, label = { Text("Futures") })
                }
                Text("Timeframes: 15m + 1h  |  RSI 14  |  MACD 12,26,9")
                Spacer(Modifier.height(8.dp))
                Button(
                    enabled = !scanning,
                    onClick = {
                        scanning = true
                        results = emptyList()
                        scanned = 0
                        status = "Loading USDT symbols…"
                        scope.launch {
                            try {
                                val isFutures = futures
                                val symbols = withContext(Dispatchers.IO) { api.symbols(isFutures) }
                                total = symbols.size
                                status = "Scanning ${symbols.size} USDT pairs…"
                                val found = mutableListOf<Signal>()
                                for (symbol in symbols) {
                                    if (!isActive) break
                                    try {
                                        val data = withContext(Dispatchers.IO) {
                                            val c15 = api.candles(symbol, "15m", isFutures)
                                            val c1h = api.candles(symbol, "1h", isFutures)
                                            val p = api.lastPrice(symbol, isFutures)
                                            Triple(c15, c1h, p)
                                        }
                                        val close15 = data.first.map { it[0] }
                                        val close1h = data.second.map { it[0] }
                                        val r15 = rsi(close15)
                                        val r1h = rsi(close1h)
                                        val m15 = macdState(close15)
                                        val m1h = macdState(close1h)

                                        val buy = r15 < 40 && m15.first && r1h < 55 && (m1h.first || r1h < 40)
                                        val sell = r15 > 60 && m15.second && r1h > 45 && (m1h.second || r1h > 60)
                                        if (buy || sell) {
                                            val dir = if (buy) if (isFutures) "LONG" else "BUY"
                                                       else if (isFutures) "SHORT" else "SELL"
                                            found.add(Signal(
                                                symbol, if (isFutures) "Futures" else "Spot", dir, data.third,
                                                r15, r1h,
                                                if (m15.first) "Bullish cross" else if (m15.second) "Bearish cross" else "No cross",
                                                if (m1h.first) "Bullish cross" else if (m1h.second) "Bearish cross" else "No cross",
                                                "15m RSI + MACD confirmation; 1h trend filter"
                                            ))
                                            results = found.toList()
                                        }
                                    } catch (_: Exception) {
                                        // Skip temporarily unavailable or delisted pairs; continue scanning.
                                    }
                                    scanned++
                                    status = "Scanned $scanned / $total • Signals: ${found.size}"
                                    delay(250) // Gentle pacing; full-market scan can take several minutes.
                                }
                                status = "Scan complete • $scanned / $total pairs • ${found.size} signals"
                            } catch (e: Exception) {
                                status = "Error: ${e.message ?: "Could not reach Binance"}"
                            } finally {
                                scanning = false
                            }
                        }
                    }
                ) { Text(if (scanning) "Scanning…" else "Scan all USDT pairs") }
                Spacer(Modifier.height(8.dp))
                if (scanning && total > 0) LinearProgressIndicator(progress = { scanned.toFloat() / total })
                Text(status, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Text("Signals", style = MaterialTheme.typography.titleLarge)
                if (results.isEmpty()) {
                    Text("No signals yet. A scan may take several minutes. No signal is not a buy/sell recommendation.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(results) { s ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(s.symbol, style = MaterialTheme.typography.titleMedium)
                                        Text(s.direction, style = MaterialTheme.typography.titleMedium)
                                    }
                                    Text("${s.market} • Last price: ${"%.8f".format(s.price)}")
                                    Text("RSI 15m: ${"%.1f".format(s.rsi15)}  |  RSI 1h: ${"%.1f".format(s.rsi1h)}")
                                    Text("MACD 15m: ${s.macd15}  |  MACD 1h: ${s.macd1h}")
                                    Text(s.note, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Educational signals only. RSI/MACD can produce false signals. Verify the chart and manage risk; this app does not place orders or guarantee profit.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
