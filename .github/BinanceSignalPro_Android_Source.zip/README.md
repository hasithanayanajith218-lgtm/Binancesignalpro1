# Binance Signal Pro (Android source project)

An Android starter app that scans Binance USDT pairs in Spot or USDⓈ-M Futures and displays RSI/MACD signals on 15m and 1h candles.

## What it does
- Public Binance market-data endpoints only; no API key, password, wallet access, or order placement.
- Spot/Futures market toggle.
- Loads trading USDT pairs and checks 15m + 1h klines.
- RSI(14), MACD(12,26,9); excludes the currently-forming candle.
- Shows BUY/SELL for Spot and LONG/SHORT for Futures when the signal rules align.

## Important limitations
- A full-market scan can take several minutes and Binance may rate-limit requests. Failed pairs are skipped; run another scan later.
- The current version displays the last market price and signal conditions only. It does **not** calculate guaranteed entry/stop-loss/take-profit levels or send background notifications.
- Signals are educational indicators, not financial advice. RSI/MACD signals can fail; paper-test before risking money.
- Futures signals are directional only; the app does not open positions or manage leverage.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, then press Run; or use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

## Signal rules
- BUY/LONG: 15m RSI < 40, 15m MACD bullish crossover, and 1h RSI < 55 with either 1h bullish crossover or 1h RSI < 40.
- SELL/SHORT: 15m RSI > 60, 15m MACD bearish crossover, and 1h RSI > 45 with either 1h bearish crossover or 1h RSI > 60.

These are starter rules and should be backtested and adjusted before live use.
